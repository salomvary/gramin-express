'use strict'

module.exports = {
  clientId: '9186',
  clientSecret: '0cbc37b418df3b3a0d262f8ae52e197dd0c6ea2c'
}
