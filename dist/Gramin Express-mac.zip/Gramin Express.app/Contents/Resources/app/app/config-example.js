'use strict'

module.exports = {
  clientId: 'your_client_id',
  clientSecret: 'your_client_secret'
}
